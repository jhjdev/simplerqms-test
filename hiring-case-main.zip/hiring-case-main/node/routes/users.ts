import * as express from 'express';
const userRouter = express.Router();

import sql from '../utils/db.ts'

/* Hello World function. */
userRouter.get('/', async function (req, res, next) {
  const users = await sql`
    SELECT *
    FROM users
  `;

  res.json(users);
});

export default userRouter;
