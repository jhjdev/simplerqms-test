CREATE TABLE groups (
  id    serial primary key,
  name  varchar(255),
  created_at  TIMESTAMP NOT NULL DEFAULT current_timestamp,
  updated_at  TIMESTAMP NOT NULL DEFAULT current_timestamp
);

CREATE TABLE users (
  id    serial primary key,
  name  varchar(255),
  email varchar(255) NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT current_timestamp,
  updated_at  TIMESTAMP NOT NULL DEFAULT current_timestamp
);

INSERT INTO users(name, email) VALUES ('Testy McTestTest', 'test@test.com');
INSERT INTO groups(name) VALUES ('Test Group');