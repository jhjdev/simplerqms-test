# frozen_string_literal: true

class Group < ApplicationRecord

end