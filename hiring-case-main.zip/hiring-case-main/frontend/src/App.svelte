<script lang="ts">
  interface User {
    id: number;
    name: string;
    email: string;
  }

  let users: User[] = $state([]);

  async function loadUsers() {
    const response = await fetch("http://localhost:3000/api/users");

    users = await response.json();
  }

  loadUsers();
</script>

<main>
  <h1>Users</h1>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
      </tr>
    </thead>

    <tbody>
      {#each users as user}
        <tr>
          <td>{user.id}</td>
          <td>{user.name}</td>
          <td>{user.email}</td>
        </tr>
      {/each}
    </tbody>
  </table>
</main>

<style>
  table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
  }
  tr {
    border-bottom: 1px solid #ddd;
  }

  td,
  th {
    display: table-cell;
    text-align: left;
    padding: 8px;
    vertical-align: top;
  }
</style>
